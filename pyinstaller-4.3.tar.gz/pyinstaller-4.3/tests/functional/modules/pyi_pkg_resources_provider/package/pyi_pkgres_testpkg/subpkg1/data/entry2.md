Data entry #2 in `subpkg1/data`.
